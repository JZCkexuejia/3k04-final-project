# How to Run The Program
## Requirements
* PySide6
* qt_material

## Build & Run
* Step 1: Run `python createui.py` to compile ui file
* Step 2: Run `python main.py`, enjoy!